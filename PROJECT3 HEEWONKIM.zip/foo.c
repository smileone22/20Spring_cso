  
#include <stdio.h>

/*
 *author: Heewon Kim
 this function shows the implementation of foo function based on given/foo.o disassembled code
 */

long foo(long a, long b){
  long result=(13*a)<<2;
  long foo=3*b;
  long c=(foo<<5)-foo;
  result=result+c;
  long d=b-a;
  c=((3*d)<<5)-d;
  result=result+c;
  return result;
}