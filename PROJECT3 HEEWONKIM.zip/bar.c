#include <stdio.h>
#include <stdlib.h>
/*
 *author: Heewon Kim
 *output: long res
 *bar function overall performs arithmetic expressions on the two parameters and uses a while loop to add the overall val to the variable ret while a<=b.
 */




long bar (long a, long b){
	long temp1=b<<4;
	long res=0;
	long val=11*a;
	val=val+2*b;
	val=val-temp1+1;

	while(a<=b){
		a++;
		res=res+val;
	}
	return res;
}
