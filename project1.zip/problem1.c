// implement your program here
#include <stdio.h>
#include <stdlib.h>

/*
* Author: Heewon Kim
* Purpose: convert date/time specification from multi-integer human readable format to a single integers
* Language:  C
*/

/*
* function that checks the validity for the digit of each date and time
 @ returns  0 if invalid and 1 if valid
*/
int check_date(int month2, int month1, int day2, int day1, int hr2, int hr1, int min2, int min1, int sec2, int sec1) {
    if (month2 < 0 || month2>1) {
        return 0;
    }
    else if (month2 == 1 && month1 > 2) {
        return 0;
    }
    else if (month1 < 0 || month2>9) {
        return 0;
    }
    else if (day2 < 0 || day2>3) {
        return 0;
    }
    else if (day1 < 0 || day1>9) {
        return 0;
    }
    else if (hr2 < 0 || hr2>2) {
        return 0;
    }
    else if (hr1 < 0 || hr1>9) {
        return 0;
    }
    else if (min2 < 0 || min2>6) {
        return 0;
    }
    else if (min1 < 0 || min1>9) {
        return 0;
    }
    else if (sec2 < 0 || sec2>6) {
        return 0;
    }
    else if (sec1 < 0 || sec1>9) {
        return 0;
    }

    return 1;


}

/*
* function that converts date and time to a single integer 
sec1- bits 0-3 used to represent the ones digit in seconds s**s** (valid values are 0-9)
sec2- bits 4-6 used to represent the tens digit in seconds **s**s (valid values are 0-6)
min1- bits 7-10 used to represent the ones digit in minutes m**m** (valid values are 0-9)
min2- bits 11-13 used to represent the tens digit in minutes **m**m (valid values are 0-6)
hr1- bits 14-17 used to represent the ones digit in hour h**h** (valid values are 0-9)
hr2- bits 18-19 used to represent the tens digit in hour **h**h (valid values are 0-2)
day1- bits 20-23 used to represent the ones digit in day D**D** (valid values are 0-9)
day2- bits 24-25 used to represent the tens digit in day **D**D (valid values are 0-3)
month1- bits 26-29 used to represent the ones digit in month M**M** (valid values are 0-9)
month2- bit 30 used to represent the tens digit in month **M**M (valid values are 0-1)

used bitwise operators to shift and insert values into 32 bits. 
 @ returns result of integer
*/
int convert_to_single_int(int month2, int month1, int day2, int day1, int hr2, int hr1, int min2, int min1, int sec2, int sec1) {
    int result = 0;
    //sec1 and sec2
    result = result | (sec1 & 0xF);
    result = result | ((sec2 & 0x7) << 4);

    //min1 and min2
    result = result | ((min1 & 0xF) << 7);
    result = result | ((min2 & 0x7) << 11);

    //hr1 and hr2
    result = result | ((hr1 & 0xF) << 14);
    result = result | ((hr2 & 0x3) << 18);

    //day1 and day2
    result = result | ((day1 & 0xF) << 20);
    result = result | ((day2 & 0x3) << 24);

    //month1 and month2
    result = result | ((month1 & 0xF) << 26);
    result = result | ((month2 & 0x1) << 30);

    //bit 31 not used
    return result;
    
}


int main() {
    int x;
    int numofi;
    int dd;
    int mm;
    int hh;
    int minmin;
    int ss;
    int month2;
    int month1;
    int day2;
    int day1;
    int hr2;
    int hr1;
    int min2;
    int min1;
    int sec2;
    int sec1;
    int final;
    printf("Number of dates you want to enter: \n");

    scanf("%d", &numofi);
    printf("Enter date (DD/MM hh:minmin:ss format): \n ");
    char* input = (char*)malloc(numofi * sizeof(char));

    for (x = 0; x < numofi; x++) {
        printf("Input#%d: ", x + 1);

        //scanf(" %[^\n]s", &input[x]);
        scanf("%d/%d %d:%d:%d", &mm, &dd, &hh, &minmin, &ss);
        month2 = mm / 10;
        month1 = mm % 10;
        day2 = dd / 10;
        day1 = dd % 10;
        hr2 = hh / 10;
        hr1 = hh % 10;
        min2 = minmin / 10;
        min1 = minmin % 10;
        sec2 = ss / 10;
        sec1 = ss % 10;


        if (check_date(month2, month1, day2, day1, hr2, hr1, min2, min1, sec2, sec1) == 0) {
            printf("INVALID \n");
        }
        else {
            final = convert_to_single_int(month2, month1, day2, day1, hr2, hr1, min2, min1, sec2, sec1);
            printf("%d\n", final);
        }

    }


}