// implement your program here
#include <stdio.h>
#include <stdlib.h>

/*
* Author: Heewon Kim 
* Purpose: split a binary number `n` into two numbers `an`, `bn` as follows.
    Let `0 ≤ i1 < i2 < ... < ik` be the indices of the bits (with the least significant bit having index 0) in `n` that are 1. Then the indices of the bits
    of `an` that are 1 are `i1`, `i3`, `i5`, ... and the indices of the bits of `bn`
    that are 1 are `i2`, `i4`, `i6`, ...
* Language:  C
*/


//`n` between 1 and 2 ^ (31) - 1
const int N = 32;

int main()
{
    int n;

    //terminate if n is zero
    while (~scanf("%d", &n) && n) {
        
        int b = 0, count = 0;
        int i = 0;
        for (i = 0; i < N; i++)
            //used n and bitwise operator & to let the indices of the bits in `n` that are 1 and 
            //used  count to check if the indice is odd or even  
            if ((1 << i) & n && (count++) & 1) {
                //add (left shifted 1 by i) into b  
                b += 1 << i;
            }

        //print a and b where n-b is a 
        printf("%d %d\n", n - b, b);
    }

}

