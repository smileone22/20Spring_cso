#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/*
* Author: Heewon Kim
* Purpose: to combine three separate red, green, and blue values to represent
a single hexadecimal number.


The objective of your program is to read the three values representing the three
separate colors and produce a single hexadecimal value.


* Language:  C
*/

/*
A function to check each color value is in the range of [0,255]
@return 1 if number is valid and 0 if invalid
*/

int check_valid(int num) {
    if (0 <= num && num <= 255) {
        return 1;
    }
    else {
        return 0;
    }
}

/*
Helper method to convert into hexadecimal symbols that changes c into a character.
*/

char convert(int c) {
    if (c == 0) {
        return '0';
    }
    else if (c == 1) {
        return '1';
    }
    else if (c == 2) {
        return '2';
    }
    else if (c == 3) {
        return '3';
    }
    else if (c == 4) {
        return '4';
    }
    else if (c == 5) {
        return '5';
    }
    else if (c == 6) {
        return '6';
    }
    else if (c == 7) {
        return '7';
    }
    else if (c == 8) {
        return '8';
    }
    else if (c == 9) {
        return '9';
    }
    else if (c == 10) {
        return 'A';
    }
    else if (c == 11) {
        return 'B';
    }
    else if (c == 12) {
        return 'C';
    }
    else if (c == 13) {
        return 'D';
    }
    else if (c == 14) {
        return 'E';
    }
    else if (c == 15) {
        return 'F';
    }
}

/*
A function that converts int values into a single string
@returns a string containg rgb values in the form of RRGGBB , a single hexadecimal value.
*/
char* make_Hex(int red, int green, int blue) {
    
    char* Hex = malloc(6);
    //red - 8
    //left shift 4 to only leave first four bits from for example, 0xFF
    char ch1 = convert(red >> 4);
    //then add the converted char to the string 
    strncat(Hex, &ch1, 1);
    //use bitwise operator & to leave last four bits from for example, 0xFF
    char ch2 = convert(red & 0xF);
    //then add the converted char to the string 
    strncat(Hex, &ch2, 1);


    //green
    char ch3 = convert(green >> 4);
    strncat(Hex, &ch3, 1);
    char ch4 = convert(green & 0xF);
    strncat(Hex, &ch4, 1);


    //blue
    char ch5 = convert(blue >> 4);
    strncat(Hex, &ch5, 1);
    char ch6 = convert(blue & 0xF);
    strncat(Hex, &ch6, 1);

    return Hex;
}



int main(void)

{

    int numofi; 
    char* str;
    printf("Number of rgb you want to enter: \n");
    scanf("%d", &numofi);
    int red = 0;
    int green = 0;
    int blue = 0;
    int x;
    for (x = 0; x < numofi; x++) {
        
        scanf("%i, %i, %i", &red, &green, &blue);
        //the case where any of the int values are invalid numbers
        if (check_valid(red) == 0 || check_valid(green) == 0 || check_valid(blue) == 0) {
            printf("INVALID \n");
        }

        //create and print out the color
        else {
            str = make_Hex(red, green, blue);
            printf("#%s \n", str);
            free(str);
        }

    }




    return 0;

}