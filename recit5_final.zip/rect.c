#include <stdio.h>
#include "rect.h"


double rect_area(Rect r){
	double width = r.upperright.x-r.lowerleft.x;
	double height= r.upperright.y-r.lowerleft.y;
	return height*width;
}

int is_in_rect(Rect r, Point p){
	
	return (p.x <= r.upperright.x) && (p.x >=r.lowerleft.x) && (p.y<=r.upperright.y) && (p.y>=r.lowerleft.y);
}


