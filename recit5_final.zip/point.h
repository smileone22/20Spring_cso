#include <stdio.h>
#ifndef POINT_H_
#define POINT_H_
typedef struct {
	double x;
	double y;
} Point;

#endif

