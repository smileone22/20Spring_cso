
#include "point.h"
#include <math.h>
#include <stdio.h>



void point_show(Point point){
	printf(" point x: %f, point y: %f ",point.x,point.y);
}

float point_dist (Point p1, Point p2){
	float distance;
	int x, y;
	x=p1.x-p2.x;
	y=p1.y-p2.y;
	distance=sqrt((x*x)+(y*y)); 
	return distance;
}

int point_eq(Point p1, Point p2){
	float dis;
	dis=point_dist(p1,p2);

	if (dis<0.000001){
		return 1; //two points equal
	}
	else{
		return 0; //two points different 
	}

}
	

