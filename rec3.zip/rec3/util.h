void print_in_binary(char);

void part_completed(int);