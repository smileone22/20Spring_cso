#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "float.h"


/*
 * Determines if the parameter f uses special value 
 * encoding. 
 * 
 * @input: f - floating point number to test 
 * @return: zero if false, and any non-zero value if true.
 */
int is_special ( float f ) {
  int n = get_E(f);
  if (n == 255){
    return 1;
  }
  return 0;
}


/*
 * Computes and return the value of M (fractional part) of   
 * IEEE single precision floating point number. 
 * 
 * @input: f- floating point number to extract the mantissa from 
 * @Return value: the mantissa of f. If f is a special value, this function should return 
 * 0.0 to indicate that f is either +INFINITY or -INFINITY 
 * and any other non-zero value to indicate that f is +NAN or -NAN. 
 * 
 */
float get_M  ( float f ) {
  int *p = &f;
  int temp = *p;
  int position, i;
  float mantissa;
  float frac = 0.0;

  int Evl = get_E(f);
  
  for(i=22; i>=0; i--){
    position = temp&1 << i;
    //if 0 at position  frac
    if (position != 0)
      frac += powf(2, -1*(23-i)); 
  }
  
  //denormalized case
  if(Evl == -126){
    mantissa = 0.0 + frac;
  }
  //special values
  else if(Evl == 255){
    //infinity
    if(frac==0)
      mantissa = 0.0 + frac;
    //nan 
    else if(frac!= 0)
      mantissa = 0.0 + frac;
  }
  
  else{
    mantissa = 1.0 + frac; 
  }

  return mantissa;
}

/*
 * Computes and return the value of s (sign) of   
 * IEEE single precision floating point number. 
 * 
 * @input: f - floating point number to extract the sign from 
 * @return: -1 if negative or +1 if positive 
 *  
 */
int get_s ( float f ) {
  if (signbit(f)){ 
    return -1;
  }
	return 1;
}


/*
 * Computes and return the value of E (exponent) of   
 * IEEE single precision floating point number. 
 * E = exp - bias (127 for single precision)
 * @input: f - floating point number to extract the exponent from 
 * @return: the value of the exponent 
 * 
 */
int get_E ( float f ) {
  //initialize and declar variables
  int br, i, E;
  int exp = 0; 
  int *p = &f;
  int temp = *p;
  
  for (i=30; i>=23; i--){
    br = temp&1 << i;
    //calculate exp when there is 1 is at the bit position
    if(br != 0){ 
      exp = exp+ (int) (powf(2, i-23)); 
    }
  }
   //denormalized case
  if(exp == 0)
    E = 1 - 127; 
  //special value case
  else if(exp == 255 || exp == -255)
    E = 255; 
  //single precision
  else
    E = exp - 127;

    return E;
}