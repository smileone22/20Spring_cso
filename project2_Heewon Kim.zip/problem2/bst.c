#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bst.h"


void add ( bst_node ** root, char * word ) {
    //initialize variable fields and declare necessary variables
    bst_node *newNode=(bst_node*)malloc(sizeof(bst_node));
  	newNode->data = word; 
  	newNode->left = NULL;
  	newNode->right = NULL;

    bst_node *target = NULL;
    int direction; //tells you which direction one should go, right=0,left-1
  	
    //wrong input case
    if (newNode==NULL){
  		return; 
  	}

    //current node
  	bst_node *current = *root;

    //case where the newNode should be added at the root
  	 if(*root==NULL) {
    (*root) = newNode;
    return;
  	}

  	//search
    while (current!=NULL) { 
    int compare = strcmp(word, current->data);
    target = current;
    //input word smaller than current node's data, go left and newNode should also go left
    if (compare < 0) { 
      current = current->left; 
      direction = 1; 
    }

    //input word bigger than current node's data, go right and newNode should also go right
    else { 
      current = current->right;
      direction = 0; //
    }//endif
  }//endwhile 
    if(!direction){ 
      target->right = newNode; //add
    }
    else{
      target->left = newNode;
      
    }//endif
}

 
void inorder ( bst_node * root ) {
    if (root != NULL) 
    { 
        inorder(root->left); 
        printf("%s ", root->data); 
        inorder(root->right); 
    } 
}

 
char * removeSmallest (  bst_node ** root ){
  bst_node *targetp = NULL; //parent of the smallest node
  bst_node *p=*root;
  char *word;
  //the case where root is NULL
  if(*root==NULL){ 
    return NULL;
  }
  //the case where root is the min node
  else if(p->left == NULL){
    word = p->data;
    (*root) = p->right; 
    //remove root
    free(p); 
    p = NULL;
    return word;
  }
  //find the min node
  while(p->left != NULL){ 
    targetp = p;
    p = p->left;
  }//end while    
   word = p->data;
   targetp->left = p->right;
   //delete node
   free(p); 
   p = NULL;
   return word;

}

 
char * removeLargest (  bst_node ** root ){
    bst_node *targetp = NULL; //parent of the largest node
    bst_node *p =*root;
    char *word; 
    
    //the case where root is NULL
    if(*root==NULL){  
      return NULL;
    }

    //root being the max node,reset root
    else if(p->right == NULL){
      word = p->data;
      (*root) = p->left; 
      free(p); 
      p = NULL;
      return word;
    }

  //find the right most node and delete
    while(p->right){
      targetp = p;
      p = p->right; 
    }
    word= p->data;
    targetp->right = p->left;
    free(p); 
    p = NULL;

  
    return word;
}




