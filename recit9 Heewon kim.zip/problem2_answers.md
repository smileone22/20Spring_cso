2.
Question 1 
1-1)
movl $97, %edi
movl $65, %esi

1-2)
movl $97, %edi
movl $65, %esi

1-3)
movl $97, %edi
movl $65, %esi

1-4)
Sizes of the registers in each case are all the same. 

1-5)
 values stored in the same place $97, $65 

 
Question 2 
function 1 is max_int 
function 2 is max_long
function 3 is max_char
