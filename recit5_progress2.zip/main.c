#include <stdio.h>
#include <assert.h>
#include "rect.c"
#include "point.c"

int main(){
	Point testp1;
	testp1.x=0.25;
	testp1.y=5.25;

	Point testp2;
	testp2.x=7.25;
	testp2.y=7.25;

	//test function point_show(Point point)
	point_show(testp1); //should print ("It is in First quadrant \n"); 

	//test function point_dist (Point p1, Point p2)
	double testdistance=14.0;
	assert(point_dist (testp1, testp2)==testdistance);

	//create rectangle 

	Rect testrect;
	testrect.lowerleft.x=1.0;
	testrect.lowerleft.y=1.0;
	testrect.upperright.x=7.0;
	testrect.upperright.y=7.0;
	double testarea=36.0;
	//test function double rect_area(Rect r)

	assert(rect_area(testrect)==testarea);

	//test if a point is in rect inpoint1(5.5,6.5) =>true/1 , inpoint2(0.25,9.25)=>false/0
	Point inpoint1;
	inpoint1.x=5.5;
	inpoint1.y=6.5;
	Point inpoint2;
	inpoint2.x=0.25;
	inpoint2.y=9.25;
	int true=1;
	int false=0;
	assert(is_in_rect(testrect, inpoint1)==true);
	assert(is_in_rect(testrect, inpoint2)==false);

	return 0;

}