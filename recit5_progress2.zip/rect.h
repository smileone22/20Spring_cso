#include <stdio.h>
#include "point.h"

typedef struct rect{
	Point lowerleft;
	Point upperright;

} Rect;
