#include <stdio.h>

typedef struct {
	double x;
	double y;
} Point;

